﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Phonebook
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void Search_Click(object sender, EventArgs e)
        {

        }

        private void Search_TextChanged(object sender, EventArgs e)
        {

        }

        private void name_Click(object sender, EventArgs e)
        {

        }

        private void name_TextChanged(object sender, EventArgs e)
        {

        }

        private void surname_Click(object sender, EventArgs e)
        {

        }

        private void surname_TextChanged(object sender, EventArgs e)
        {

        }

        private void telenum_Click(object sender, EventArgs e)
        {

        }

        private void telenum_TextChanged(object sender, EventArgs e)
        {

        }

        private void email_Click(object sender, EventArgs e)
        {

        }

        private void email_TextChanged(object sender, EventArgs e)
        {

        }

        private void dob_Click(object sender, EventArgs e)
        {

        }

        private void dob_TextChanged(object sender, EventArgs e)
        {

        }

        private void edit_Click(object sender, EventArgs e)
        {
            panel1.Enabled = true;
            txtPhoneNumber.Focus();

        }

        private void save_Click(object sender, EventArgs e)
        {
            phoneBookBindingSource.EndEdit();
            App.PhoneBook.AcceptChanges();
            App.PhoneBook.writeXml(string.Format("{0}//data.dat" Application.StartupPath,))
                 Panel1.Enabled = false;

        }

        private void delete_Click(object sender, EventArgs e)
        {

        }

        static AppData db;
        protected static AppData App
        { 
            get
            {
                if (db == null)
                    db = new AppData;
                return db;
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            string filename = string.Format("{0}//data.dat", Application.StartupPath);
            if (file.Exists(filename))
                App.Phonebook.ReadXml(filename);
            PhonebookBindingSource.DataSource=App.Phonebook;
            Panel1.Enabled = false;
        }
    }
}
